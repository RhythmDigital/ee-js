(function(){

    var namespace = MAIN.namespace('widgets');

    if (namespace.FilterCounter === undefined) 
	{
        namespace.FilterCounter = function()
		{	
		};

		var p = namespace.FilterCounter.prototype;

		p.init = function() {
			console.log("NEW FilterCounter!!!!");
		};

	}

})();